﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Donationap2
{

    public partial class Donationform2 : Form
    {
        const int NUMBER_OF_TEAMS = 8;
        struct Account
        {
            public int teamNumber;
            public double amount;
        }

        Account[] accounts;

        void init ()
        {
            accounts = new Account[NUMBER_OF_TEAMS];
            accounts[0].teamNumber = 5;
            accounts[1].teamNumber = 7;
            accounts[2].teamNumber = 9;
            accounts[3].teamNumber = 10;
            accounts[4].teamNumber = 15;
            accounts[5].teamNumber = 30;
            accounts[6].teamNumber = 35;
            accounts[7].teamNumber = 40;
        }
        int getTeamIndex(int teamNumber)
        {
            for (int i = 0; i < accounts.Length; i++)
            {
                if (accounts[i].teamNumber==teamNumber)
                {
                    return i;
                }
            }
            return -1;
        }
        public Donationform2()
        {
            InitializeComponent();
        }

        private void btnDeposit_Click(object sender, EventArgs e)
        {
            try
            {
                int teamNumber = int.Parse(txtTeamNumber.Text);
                int index = getTeamIndex(teamNumber);
                if (index == -1)
                {
                    throw new Exception("Invalid team Number");
                }
                try
                {
                    double amount = double.Parse(txtAmount.Text);
                    accounts[index].amount += amount;
                }
                catch (Exception ex)
                {

                    MessageBox.Show("Error in amount" + ex.Message);
                }
            }
            catch (Exception ex)
            {

                MessageBox.Show("Error in team number" +ex.Message);
            }
        }

        private void btnShow_Click(object sender, EventArgs e)
        {
            string result = "";
            for (int i = 0; i <accounts.Length; i++)
            {
                result += "team: " + accounts[i].teamNumber + "--" + accounts[i].amount
                    + "\n";

            }
        }

        private void rtxOutput_TextChanged(object sender, EventArgs e)
        {

        }
    }
}

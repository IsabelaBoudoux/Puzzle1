﻿namespace Donationap2
{
    internal class Account
    {
    }
}
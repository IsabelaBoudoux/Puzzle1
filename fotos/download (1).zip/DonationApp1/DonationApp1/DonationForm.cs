﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DonationApp1
{
    public partial class DonationForm : Form
    {
        public const int NUMBER_OF_TEAMS = 8;
        private double[] accounts = new double[NUMBER_OF_TEAMS];

        public DonationForm()
        {
            InitializeComponent();
        }

        private void btnDeposit_Click(object sender, EventArgs e)
        {

            try
            {
                int teamNumber = int.Parse(txtTeamNumber.Text);

                if (teamNumber < 0 || teamNumber >= NUMBER_OF_TEAMS )
                {
                    //MessageBox.Show("Team number must be 0-7");
                    //return;
                    throw new Exception("Team number must be 0-7");
                }

                try
                {
                    double amount = double.Parse(txtAmount.Text);

                    accounts[teamNumber] += amount;
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Enter valid number for amount " + ex.Message);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Enter a valid team number " + ex.Message );
            }

        }

        private void btnShow_Click(object sender, EventArgs e)
        {
            string result = "";
            for (int i = 0; i < accounts.Length; i++)
            {
                result += "Team: " + i + " ---- " + accounts[i] + "\n";
            }

            rtxOutput.Text = result;
        }
    }
}

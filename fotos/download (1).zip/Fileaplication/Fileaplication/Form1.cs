﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace Fileaplication
{
    public partial class Form1 : Form
    {
        private Stream fileName;

        public Form1()
        {
            InitializeComponent();
        }
        private void save(string fileName)
        {
            StreamWriter writer = new StreamWriter(fileName);
            int numberOfItens = int.Parse(txtNumberOfItens.Text);
            writer.WriteLine(numberOfItens);
            Random r = new Random();

            for (int i = 0; i < numberOfItens; i++)
            {
                writer.WriteLine(r.Next(0, 100));
            }
            writer.Close();
        }

        private void saveToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            DialogResult r = dlgsave1.ShowDialog();
            switch (r)
            {
                case DialogResult.None:
                    break;
                case DialogResult.OK:
                    try
                    {
                        string fileName = dlgsave1.FileName;
                        save(fileName);
                    }
                    catch (Exception ex)
                    {

                        MessageBox.Show("error in file save");
                    }
                        break;
                case DialogResult.Cancel:
                    break;
                case DialogResult.Abort:
                    break;
                case DialogResult.Retry:
                    break;
                case DialogResult.Ignore:
                    break;
                case DialogResult.Yes:
                    break;
                case DialogResult.No:
                    break;
                default:
                    break;
            }


        }
        private void load(string fileName)
        {
            StreamReader reader = new StreamReader(fileName);
            int numberOfItems = int.Parse(reader.ReadLine());
            for (int i = 0; i < numberOfItems; i++)
            {
                Console.WriteLine(reader.ReadLine());
            }
            reader.Close();
        }
        
        private void loadToolStripMenuItem_Click(object sender, EventArgs e)
        {
            DialogResult dialogResult= dlgLoad

        }
    }
}
